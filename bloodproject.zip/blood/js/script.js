document.addEventListener('DOMContentLoaded', function() {
    console.log('DOM fully loaded and parsed'); // Check if the script is running
    const form = document.getElementById('registrationForm');

    if (form) {
        console.log('Form found'); // Check if the form is found
        form.addEventListener('submit', function(event) {
            event.preventDefault(); // Prevent the default form submission
            console.log('Form submitted'); // Check if the event listener is working

            // Show the popup message
            alert('Thank you for registering as a donor!');

            // Optionally, you can submit the form after showing the popup
            form.submit();
        });
    } else {
        console.log('Form not found'); // Check if the form is not found
    }
});
