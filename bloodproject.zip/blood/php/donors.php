<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "blood_donation";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$search = '';
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $search = $_POST['search'];
}

$sql = "SELECT name, age, blood_type, contact, email, donation_date, next_eligibility_date FROM donors";
if ($search) {
    $sql .= " WHERE blood_type = '$search'";
}
$result = $conn->query($sql);
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Donors - Blood Donation</title>
    <link rel="stylesheet" href="../css/styles.css">
</head>
<body>
    <header>
        <h1>Registered Donors</h1>
        <nav>
            <ul>
                <li><a href="../index.html">Home</a></li>
                <li><a href="../register.html">Register</a></li>
                <li><a href="donors.php">Donors</a></li>
            </ul>
        </nav>
    </header>
    <main>
        <section>
            <h2>List of Donors</h2>
            <form method="POST" action="donors.php">
                <label for="search">Search by Blood Group:</label>
                <input type="text" id="search" name="search">
                <button type="submit">Search</button>
            </form>
            <table>
                <tr>
                    <th>Name</th>
                    <th>Age</th>
                    <th>Blood Type</th>
                    <th>Contact</th>
                    <th>Email</th>
                    <th>Donation Date</th>
                    <th>Next Eligibility Date</th>
                </tr>
                <?php
                if ($result->num_rows > 0) {
                    while($row = $result->fetch_assoc()) {
                        echo "<tr><td>" . $row["name"]. "</td><td>" . $row["age"]. "</td><td>" . $row["blood_type"]. "</td><td>" . $row["contact"]. "</td><td>" . $row["email"]. "</td><td>" . $row["donation_date"]. "</td><td>" . $row["next_eligibility_date"]. "</td></tr>";
                    }
                } else {
                    echo "<tr><td colspan='7'>No donors found</td></tr>";
                }
                ?>
            </table>
        </section>
    </main>
    <footer>
        <p>&copy; 2024 Blood Donation</p>
    </footer>
</body>
</html>

<?php
$conn->close();
?>
