<?php
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "blood_donation";

// Create connection
$conn = new mysqli($servername, $username, $password, $dbname);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $name = $_POST['name'];
    $age = $_POST['age'];
    $blood_type = $_POST['blood_type'];
    $contact = $_POST['contact'];
    $email = $_POST['email'];
    $donation_date = $_POST['donation_date'];

    // Calculate next eligibility date (assuming 56 days interval for the next donation)
    $next_eligibility_date = date('Y-m-d', strtotime($donation_date . ' + 56 days'));

    $sql = "INSERT INTO donors (name, age, blood_type, contact, email, donation_date, next_eligibility_date) VALUES ('$name', $age, '$blood_type', '$contact', '$email', '$donation_date', '$next_eligibility_date')";

    if ($conn->query($sql) === TRUE) {
        echo "New record created successfully";
    } else {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

$conn->close();
?>
